package com.app.ConStructCompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConStructCompanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConStructCompanyApplication.class, args);
	}

}
